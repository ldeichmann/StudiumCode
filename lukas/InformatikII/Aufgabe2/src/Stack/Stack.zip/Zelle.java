package Stack;

class Zelle<E>{
	E inhalt;
	Zelle<E> next;
	Zelle(E e) {inhalt = e;}
}
