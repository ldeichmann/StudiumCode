import java.util.LinkedList;
import java.util.List;

/**
 * 
 * Klasse Auto beschreibt ein Auto fuer einen Kfz Haendler
 *
 */
public class Auto {
	private String hersteller;
	private long laufleistung;
	private double preis;
	private String farbe;
	private boolean unfallwagen;
	private String kraftstoff;
	private double psLeistung;
//	static protected List<Auto> cars = new LinkedList<Auto>();
	
	/**
	 * Konstruktor  
	 * @param chersteller
	 * @param claufleistung
	 * @param cpreis
	 * @param cfarbe
	 * @param cunfallwagen
	 * @param ckraftstoff
	 * @param cps
	 * 
	 *  fuegt das Objekt Auto nach anlegen in cars hinzu
	 */
	public Auto(String chersteller, long claufleistung, double cpreis,
			String cfarbe, boolean cunfallwagen, String ckraftstoff, double cps) {
		
		hersteller = chersteller;
		laufleistung = claufleistung;
		preis = cpreis;
		farbe = cfarbe;
		unfallwagen = cunfallwagen;
		kraftstoff = ckraftstoff;
		psLeistung = cps;
		
	}

	/**
	 * Formatierte Ausgabe
	 */
	public String toString() {

		if (unfallwagen == true) {
			return "---" + "\nHersteller: " + hersteller + "\nPreis: " + preis
					+ " Euro" + "\nMotor: " + psLeistung + " PS " + "(" + kraftstoff
					+ ")" + "\nKM-Stand: " + laufleistung + " km" + "\nFarbe: "
					+ farbe + "\n---";
		}
		else {
			return "---" + "\nHersteller: " + hersteller + "\nPreis: " + preis
					+ " Euro" + "\nMotor: " + psLeistung + " PS " + "(" + kraftstoff
					+ ")" + "\nKM-Stand: " + laufleistung + " km" + "\nFarbe: "
					+ farbe + "\nunfallfrei" +"\n---";
		}
	}
	
	/**
	 * Diese Methode fügt ein Auto-Objekt in einen Bestand
	 * ein. Der Parameter bezeichnet dabei den das Bestand-Objekt, in das das Auto eingefügt werden
	 * soll. Die Methode liefert true, wenn das Einfügen erfolgreich war.
	 * @param b
	 * @return
	 */
	boolean zumBestandHinzu(Bestand b) {
//		if(!b.istVorhanden(this)) {
			return b.aufnehmen(this);
//		}
//		else
//			return true;
	}
	
	/**
	 * Diese Methode entfernt das Auto-Objekt (sich selbst) aus dem im
	 * Objekt gespeicherten Bestand. Sie liefert false, wenn das Auto keinem Bestand zugeordnet war,
	 * ansonsten true.
	 * @param b
	 * @return
	 */
	boolean ausDemBestand(Bestand b) {
		if(b.istVorhanden(this))
			return b.entnehmen(this);
		else
			return false;
	}
	
	
	/**
	 * Getter Methoden zur Kapselung
	 * 
	 */
	public double getPreis() {
		return preis;
	}
	
	public boolean isUnfallwagen() {
		return unfallwagen;
	}
//	
//	public String getKrafstoff() {
//		return kraftstoff;
//	}
//	
//	public String getHersteller() {
//		return hersteller;
//	}
//	
//	public long getLaufleistung() {
//		return laufleistung;
//	}
//	
//	public String getFarbe() {
//		return farbe;
//	}
//	
//	public String kraftstoff() {
//		return kraftstoff;
//	}
//	
//	public double getPs() {
//		return psLeistung;
//	}
//	
//	public static List<Auto> getBestand() {
//		return getBestand();
//	}
//	
//	public static int getAnzahl() {
//		return getBestand().size();
//	}
//	
//	/**
//	 * Errechnung des kompletten Erloeses
//	 * @return
//	 */
//	public static double getErloes() { 
//		double erloes = 0.0;
//		for(int i = 0; i < getAnzahl() ; i++) {
//			erloes += getBestand().get(i).getPreis();
//		}
//		return erloes;
//	}
//
//	/**
//	 * Errechnet prozentual die Unfallwagen
//	 * 
//	 */
//	public static double anteil_unfallwagen() {
//		int c = 0;
//		for(int i = 0; i < getAnzahl() ; i++) {
//			if(getBestand().get(i).isUnfallwagen() == true)
//				c++;
//		}
//		return (((double) c/ (double) getAnzahl())*100);
//	}
//
//	/**
//	 * Errechnet prozentual kraftstoffarten am Autobestand
//	 * 
//	 */
//	public static double anteil_kraftstoffart(String auto) {
//		int c = 0;
//		for(int i = 0; i < getAnzahl() ; i++) {
//			if(getBestand().get(i).getKrafstoff().equals(auto) == true)
//				c++;
//		}
//		return (((double) c/ (double) getAnzahl()) * 100);
//	}
//
//	/**
//	 * Errechnet Erloes mit Nachlass der uebergeben wird 
//	 *
//	 */
//	public static double erloes_inkl_nachlass(double k, double j) {
//		double erloes = 0.0;
//		for(int i = 0; i < getAnzahl() ; i++) {
//			if(getBestand().get(i).isUnfallwagen() == false)
//				erloes += ((double)getBestand().get(i).getPreis() * (1.0 - k));
//			else
//				erloes += ((double)getBestand().get(i).getPreis() * (1.0 - j));
//		}
//		return erloes;
//	}
//	
//	/**
//	 * Sortierung des Autobestandes nach Preis
//	 * 
//	 */
//	public static void bubbleSort() {
//		boolean unsorted = true;
//		while (unsorted) {
//			unsorted = false;
//			for (int i = 0; i < getAnzahl() - 1; i++) {
//				if ( !(getBestand().get(i).getPreis() >= getBestand().get(i + 1).getPreis() )) {
//					Auto dummy = getBestand().get(i);
//					getBestand().set(i, getBestand().get(i + 1));
//					getBestand().set(i + 1, dummy);
//					unsorted = true;
//				}
//			}
//		}
//	}

}
