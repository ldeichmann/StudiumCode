import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 
 * @author tweekx0r
 *
 */
public class Bestand  {
	
	static List<Auto> cars = new LinkedList<Auto>();
	
	/**
	 * Konstruktor
	 */
	public Bestand() {
//		cars = this;
	}
	
	public List<Auto> getBestand() {
		return cars;
	}
	
	/**
	 * Diese Methode prüft, ob ein Auto bereits im Bestand
	 * ist. Liefert true wenn ja, andernfalls false.
	 * @param ap
	 * @return
	 */
	boolean istVorhanden(Auto a) {
		return cars.contains(a);
	}
	
	/**
	 * Diese Methode fügt ein Auto-Objekt zum Bestand hinzu.
	 * Der Parameter referenziert das Auto-Objekt, das dem Bestand hinzugefügt werden soll. Die Methode
     * liefert false, wenn Auto-Objekt schon im Bestand vorhanden ist, ansonsten true.
	 * @param a
	 * @return
	 */
	boolean aufnehmen(Auto a) {
		if(!istVorhanden(a))
			return cars.add(a);
		else
			return false;
	}
	
	/**
	 * Diese Methode entfernt das angegebene Auto-Objekt aus
	 * dem Bestand. Die Methode liefert false, wenn Auto nicht im Bestand vorhanden war, ansonsten
	 * true.
	 * @param a
	 * @return
	 */
	boolean entnehmen(Auto a) {
		if(istVorhanden(a)) 
			return cars.remove(a);
		else
			return false;
	}
	
	/** 
	 * Diese Methode liefert alle Auto-Objekte des Bestands als
	 * Array.
	 * @return
	 */
	Auto[] getAutosAlsArray() {
		Auto[] b = null;
		if(cars.size() != 0) {
			b = cars.toArray(new Auto[cars.size()]);	
		}
		return b;
	}
	
	/**
	 * Diese Methode liefert ein nach Preis absteigend sortiertes
	 * Array von Auto-Objekten des Bestands.
	 * @return
	 */
	Auto[] sortiertNachPreis() {
		Auto[] b = null;
		boolean unsorted = true;
		while (unsorted) {
			unsorted = false;
			for (int i = 0; i < cars.size() - 1; i++) {
				if ( !(cars.get(i).getPreis() >= cars.get(i + 1).getPreis() )) {
					Auto dummy = cars.get(i);
					cars.set(i, cars.get(i + 1));
					cars.set(i + 1, dummy);
					unsorted = true;
				}
			}
			
		}
		b = cars.toArray(new Auto[cars.size()]);
		return b;
	}
	
	/**
	 * Errechnet Erloes mit Nachlass der uebergeben wird 
	 *
	 */
	public static double erloes_inkl_nachlass() {
		double erloes = 0.0;
		for(int i = 0; i < cars.size() ; i++) {
			if(cars.get(i).isUnfallwagen() == false)
				erloes += ((double)cars.get(i).getPreis()) * 0.75;
			else
				erloes += ((double)cars.get(i).getPreis()) * 0.9;
		}
		return erloes;
	}
	
	/**
	 * Errechnung des kompletten Erloeses
	 * @return
	 */
	public static double getErloes() { 
		double erloes = 0.0;
		for(int i = 0; i < cars.size() ; i++) {
			erloes += cars.get(i).getPreis();
		}
		return erloes;
	}
}
