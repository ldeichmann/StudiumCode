public class Reservierung {
	private String bemerkung;
	private Uhrzeit beginn;
	private Uhrzeit ende;
	
	protected Mitarbeiter von = null;
	protected Raum raum = null;
	
	
	public Reservierung(Uhrzeit b, Uhrzeit e) {
		beginn = b;
		ende = e;
	}
	
	public void setBemerkung(String arg) {
		bemerkung = arg;
	}
	
	public void setMitarbeiter(Mitarbeiter m) {
		von = m;
	}
	
	public void setRaum(Raum r) {
		raum = r;
		raum.addReservierung(this);
	}
	
	public String toString() {
		return "gebucht von " + von + " von " + beginn + " bis " + ende + " für " + bemerkung;
	}
}
