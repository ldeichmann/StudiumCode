
public class Person {
	private String vorname;
	private String nachname;
	
	public Person(String v, String n) {
		vorname = v;
		nachname = n;
	}
	
	public String toString() {
		return vorname + " " + nachname;
	}
}
