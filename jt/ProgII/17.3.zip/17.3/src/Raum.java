import java.util.LinkedList;
import java.util.List;


public class Raum {
	private int geb;
	private int etage;
	private int raumv;
	
	protected List<Reservierung> reservierung = new LinkedList<Reservierung>();
	
	public Raum(int g, int e, int r) {
		geb = g;
		etage = e;
		raumv = r;
	}
	
	public String toString() {
		String builder = "";
		for(Reservierung c : reservierung) {
			builder += c + "\n";
		}
		return geb + "-" + etage + "." + raumv + "\n" + builder;
	}
	
	public void addReservierung(Reservierung res) {
		reservierung.add(res);
	}
	
}
