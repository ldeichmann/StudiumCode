
public class Uhrzeit {
	private int stunde;
	private int minute;
	
	public Uhrzeit(int s, int m) {
		stunde = s;
		minute = m;
	}
	
	public String toString() {
		return stunde + ":" + minute + " Uhr";
	}

}
