import java.util.LinkedList;
import java.util.List;




public class Mitarbeiter {
	private String email;
	private Person p = null;
	
	protected List<Reservierung> buchung = new LinkedList<Reservierung>();
	
	public Mitarbeiter(String n, String nn, String e) {
		p = new Person(n, nn);
		 email = e;
	}
	
	public String toString() {
		return p + " " + email;
	}
	
	public void reservieren(Raum r, Uhrzeit b, Uhrzeit e, String n) {
		Reservierung res = new Reservierung(b,e);
		res.setMitarbeiter(this);
		res.setBemerkung(n);
		res.setRaum(r);
	}
}
	