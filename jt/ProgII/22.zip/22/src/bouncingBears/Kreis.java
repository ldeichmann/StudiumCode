package bouncingBears;

import java.awt.Color;

public class Kreis extends Ellipse {
	
	public Kreis(int x, int y, int z, int r, Color c) {
		super(x,y,z,r,r,c);
		super.figurenTyp = "Kreis";
	}
	
}
