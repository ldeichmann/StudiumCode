package bouncingBears;

import java.awt.Color;

public class Quadrat extends Rechteck{
	
	public Quadrat(int x, int y, int z, int a, Color c) {
		super(x,y,z,a,a,c);
		super.figurenTyp = "Quadrat";
	}
	
}
