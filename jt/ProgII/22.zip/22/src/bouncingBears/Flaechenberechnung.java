package bouncingBears;

public interface Flaechenberechnung {
	
	double berechneFlaeche();

}
