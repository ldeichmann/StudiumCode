package bouncingBears;

import java.awt.Graphics;
import java.util.LinkedList;
import java.util.List;

public class FigurenGruppe {

	protected int X;
	protected int Y;

	protected int DX;
	protected int DY;

	List<Figur> figs = new LinkedList<Figur>();

	public FigurenGruppe(int x, int y) {
		X = x;
		Y = y;
	}

	public FigurenGruppe(int x, int y, Figur... f) {
		X=x;
		Y=y;
		for (Figur c : f) {
			figs.add(c);
		}
	}

	public int getX() {
		return X;
	}

	public int getY() {
		return Y;
	}

	public int getDX() {
		return DX;
	}

	public FigurenGruppe setDX(int i) {
		DX = i;
		return this;
	}

	public int getDY() {
		return DY;
	}

	public FigurenGruppe setDY(int i) {
		DY = i;
		return this;
	}

	public FigurenGruppe bewege() {
		return this;
	}

	public FigurenGruppe add(Figur f) {
		figs.add(f);
		return this;
	}

	public FigurenGruppe remove(Figur f) {
		for (Figur c: this.figs) {
			if(c == f)
				remove(c);
		}
		return this;
	}

	protected FigurenGruppe sort() {
		return this;
	}

	public void zeichne(int x, int y, Graphics g) {
		for (Figur f : this.figs) {
			f.zeichne(x + this.X, y - this.Y, g);
		}
	}
}
