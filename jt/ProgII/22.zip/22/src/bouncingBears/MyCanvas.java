package bouncingBears;

import java.awt.Graphics;
import java.util.List;
import java.util.LinkedList;

import javax.swing.JPanel;

public class MyCanvas extends JPanel {

	List<FigurenGruppe> figs = new LinkedList<FigurenGruppe>();

	public MyCanvas(FigurenGruppe... fg) {
		for(FigurenGruppe c: fg) {
			figs.add(c);
		}
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		int x = this.getWidth() / 2;
		int y = this.getHeight() / 2;
		for (FigurenGruppe f : this.getFiguren()) {
			f.zeichne(x, y, g);
		}
	}

	public List<FigurenGruppe> getFiguren() {
		return figs;
	}
}
