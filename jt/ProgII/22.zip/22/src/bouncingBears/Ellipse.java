package bouncingBears;

import java.awt.Color;
import java.awt.Graphics;

public class Ellipse extends FigMZLA implements Flaechenberechnung{
	
	public Ellipse(int x, int y, int z, int a, int b, Color c) {
		super(x,y,z,a,b,c);
		super.figurenTyp = "Ellipse";
	}
	
	public double berechneFlaeche() {
		return Math.abs(Math.PI * A * B);
	}
	
	public void zeichne(int x, int y, Graphics g) {
		int x_draw = x + this.getX() - this.getA();
		int y_draw = y - this.getY() - this.getB();
		g.setColor(this.FARBE);
		g.fillOval(x_draw, y_draw, this.getA() * 2, this.getB() * 2);
	}
}
