package bouncingBears;

import java.awt.Graphics;
import java.awt.Color;

public class Rechteck extends FigMZLA{
	
	public Rechteck(int x, int y, int z, int a, int b, Color c) {
		super(x,y,z,a,b,c);
		super.figurenTyp = "Rechteck";
	}
	
	public double berechneFlaeche() {
		return Math.abs(A * B);
	}
	
	public void zeichne(int x, int y, Graphics g) {
		int x_draw = x + this.getX();
		int y_draw = y - this.getY() - this.getB();
		g.setColor(this.FARBE);
		g.fillRect(x_draw, y_draw, this.getA(), this.getB());
	}
}
