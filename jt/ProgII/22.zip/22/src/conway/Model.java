package conway;

import java.util.List;

public class Model {
	private int width;
	private int height;
	private boolean[][] actualField;
	private boolean[][] nextField;
	private List<boolean[][]> fieldHistory;
	
	public Model() {
		
	}
	
	public Model(int w, int h) {
		width = w;
		height = h;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void changeState(int w, int h) {
		
	}
	
	public void clear() {
		
	}
	
	public boolean isAlive(int w, int h) {
		return false;
	}
	
	public void nextGeneration() {
		
	}
	
	public void previousGeneration() {
		
	}
	
	private void conwayRules() {
		
	}
	
}
