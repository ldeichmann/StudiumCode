package conway;

import javax.swing.Timer;

public class Controller {
	private Timer timer;
	private Model model;
	private View view;
	
	public Controller(Model m, View v) {
		view = v;
		model = m;
	}
	
	public void pause() {
		
	}
	
	public void clear() {
		
	}
	
	public void random() {
		
	}
	
	public void clickedField(int x, int y) {
		
	}
}
