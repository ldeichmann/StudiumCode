package conway;

import javax.swing.JButton;

public class View {
	private JButton play;
	private JButton pause;
	private JButton back;
	private JButton clear;
	private JButton random;
	private JGoLField[][] field;
	private Model model;
	private Controller controler;
	
	public View() {
		
	}
	
	public void update() {
		
	}
}
