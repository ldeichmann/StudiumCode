package conway;

import java.awt.Graphics;

import javax.swing.JPanel;

public class JGoLField extends JPanel{
	private int row;
	private int col;
	private boolean alive;
	
	public JGoLField(int r, int c, boolean b) {
		row = r;
		col = c;
		alive = b;
	}
	
	public int getRow() {
		return row;
	}
	
	public int getCol() {
		return col;
	}
	
	public void setAlive(boolean a) {
		alive = a;
	}
	
	public boolean isAlive() {
		return alive;
	}
	
	public void update() {
		
	}
	
	public void paintComponent(Graphics g) {
		
	}
}
