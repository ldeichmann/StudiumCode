import java.awt.event.ActionEvent;


public interface ActionListener {
	public void actionPerformed(ActionEvent ev);
}
