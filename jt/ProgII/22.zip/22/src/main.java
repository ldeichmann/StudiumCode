import java.awt.Color;

import javax.swing.JFrame;

import java.awt.Graphics;

import javax.swing.JPanel;

import bouncingBears.*;

public class main extends JPanel {
	
	 public void paint(Graphics g) {
		    g.fillRect(30,0,200,250);
		  
	  }
	
	public static void Taschenrechner() {
		TRView f = new TRView();
		f.setSize(500, 500);
		f.setVisible(true);
	}

	public static void drawFigures() {
		FigurenGruppe gesicht1 = new FigurenGruppe(0, 0, new Kreis(0, 0, 0,
				100, Color.GRAY), // Gesicht
				new Kreis(0, -10, 1, 20, Color.RED), // Nase
				new Kreis(65, 65, -1, 40, Color.DARK_GRAY), // Linkes Ohr
				new Kreis(-65, 65, -1, 40, Color.DARK_GRAY), // Rechtes Ohr
				new Kreis(-25, 25, 1, 10, Color.WHITE), // Linkes Auge
				new Kreis(25, 25, 1, 10, Color.WHITE), // Rechtes Auge
				new Ellipse(0, -55, 1, 55, 15, Color.YELLOW), // Mund
				new Rechteck(-80, 90, 1, 160, 20, Color.GREEN), // Hut (Krempe,
																// unten)
				new Rechteck(-40, 90, 1, 80, 100, Color.GREEN) // Hut (oben)
		);
		
		JFrame mainFrame = new JFrame("not Bouncing Bears");
		mainFrame.setSize(800, 600);
		mainFrame.add(new MyCanvas(gesicht1));
		mainFrame.setVisible(true);
	}

	public static void drawFigures2() {
		FigurenGruppe baer1 = new FigurenGruppe(-150, 0, new Kreis(0, 0, 0,
				100, Color.GRAY), // Gesicht
				new Kreis(0, -10, 1, 20, Color.RED), // Nase
				new Kreis(65, 65, -1, 40, Color.DARK_GRAY), // Linkes Ohr
				new Kreis(-65, 65, -1, 40, Color.DARK_GRAY), // Rechtes Ohr
				new Kreis(-25, 25, 1, 10, Color.WHITE), // Linkes Auge
				new Kreis(25, 25, 1, 10, Color.WHITE), // Rechtes Auge
				new Ellipse(0, -55, 1, 55, 15, Color.YELLOW), // Mund

				new Rechteck(-80, 90, 1, 160, 20, Color.GREEN), // Hut (Krempe,	// unten)
				new Rechteck(-40, 90, 1, 80, 100, Color.GREEN) // Hut (oben)
		);

		FigurenGruppe baer2 = new FigurenGruppe(150, 0, 
				new Kreis(0, 0, 0, 100,	Color.GRAY), // Gesicht
				new Kreis(-25, 25, 1, 10, Color.BLUE), // Linkes Auge
				new Kreis(25, 25, 1, 10, Color.BLUE), // Rechtes Auge
				new Kreis(0, -10, 1, 20, Color.RED), // Nase
				new Kreis(65, 65, -1, 40, Color.DARK_GRAY), // Linkes Ohr
				new Kreis(-65, 65, -1, 40, Color.DARK_GRAY), // Rechtes Ohr
				new RWDreieck(0, -40, 1, -70, -30, Color.YELLOW), // Mund (links)
				new RWDreieck(0, -40, 1, 70, -30, Color.YELLOW), // Mund (rechts)
				new RWDreieck(0, 90, 1, -40, 100, Color.GREEN), // Partyhut (links)
				new RWDreieck(0, 90, 1, 40, 100, Color.GREEN) // Partyhut (rechts)
		);

		JFrame mainFrame = new JFrame("Bouncing Bears");
		mainFrame.setSize(800, 600);
		mainFrame.add(new MyCanvas(baer1, baer2));
		mainFrame.setVisible(true);
	}

	public static void main(String[] args) {
		drawFigures2();

	}
}
