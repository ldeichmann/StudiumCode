import static org.junit.Assert.*;

import org.junit.Test;

import static org.junit.Assert.*;
import java.util.LinkedList;
import java.util.List;
import org.junit.Test;

/**
 * Testet den in der Klasse Sort befindlichen BinSort Algorithmus. Vorgabe fuer
 * Aufgabe 19.2
 * 
 * @author Nane Kratzke
 */
public class BurgSortTest {

	/**
	 * Testet aufsteigenden BinSort mit einer Liste von Strings.
	 */
	@Test
	public void testBinSortWithStrings() {
		List<String> strs = new LinkedList<String>();
//		strs.add("Hello World");
//		strs.add("");++
//		strs.add("Mein Name ist Hase");
		strs.add("");
//		strs.add("Das wird schon klappen");

		BugSort<String> stringSorter = new BugSort<String>();
		List<String> sorted = stringSorter.binSort(strs);

//		System.out.println(sorted);
		
		assertTrue(sorted.get(0).equals(""));
//		assertTrue(sorted.get(1).equals("Hello World"));
//		assertTrue(sorted.get(2).equals("Mein Name ist Hase"));
		
		
	}

	/**
	 * Testet aufsteigenden BinSort mit einer Liste von Integern.
	 */
	@Test
	public void testBinSortWithIntegers() {
		List<Integer> is = new LinkedList<Integer>();
		for (int i = 0; i <= 5; i++)
			is.add(i);

		BugSort<Integer> integerSorter = new BugSort<Integer>();
		List<Integer> sorted = integerSorter.binSort(is);

		// Wir pruefen die aufsteigende Sortierung
		for (int i = 0; i < sorted.size() - 1; i++) {
				assertTrue(sorted.get(i) <= sorted.get(i + 1));
		}
	}
	
	@Test
	public void testFor19_2_1() {
		List<Integer> is = new LinkedList<Integer>();
		is.add(4);
		is.add(3);
		is.add(10);
		is.add(7);
		is.add(29);
		is.add(6);
		is.add(19);
		BugSort<Integer> integerSorter = new BugSort<Integer>();
		List<Integer> sorted = integerSorter.binSort(is,false);
		for (int i = 0; i < sorted.size() - 1; i++) {
			assertTrue(sorted.get(i) >= sorted.get(i + 1));
		}
		System.out.println(sorted);
	}
}
