import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

public class MyQueue<T> {

	List<T> list = new LinkedList<T>();

	/**
	 * boolean enter(T) fügt ein neues Element der Warteschlange hinzu. Liefert
	 * true, wenn das Element der Warteschlange hinzugefügt werden konnte,
	 * andernfalls false.
	 * 
	 * @param t
	 * @return
	 */
	public boolean enter(T t) {
		return list.add(t);
	}

	/**
	 * T leave() throws NoSuchElementException entnimmt das erste Element der
	 * Warteschlange. Ist die Warteschlange leer wirft die Methode eine
	 * java.util.NoSuchElementException.
	 * 
	 * @return
	 */
	public T leave() {
	
		T lastel = list.get(list.size() - 1);
		try {
			list.remove(lastel);
			return lastel;
		} catch (NoSuchElementException e) {
			return null;
		}
	}

	/**
	 * boolean isEmpty prüft ob die Warteschlange leer ist
	 * 
	 * @return
	 */
	public boolean isEmpty() {
		return list.isEmpty();
	}

	/**
	 * T front() liest das erste Element der Warteschlange, belässt es aber in
	 * der Warteschlange. Liefert null, wenn sich kein Element in der
	 * Warteschlange befindet.
	 * 
	 * @return
	 */
	public T front() {
		if(list.isEmpty()) return null;
		return list.get(list.size() - 1 );
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(T t: list) {
			sb.append( "[ " + t + " ]");
		}
		return sb.toString();
	}

}
