import de.fhl.oop.tictactoe.engine.T3Starter;
import de.fhl.oop.tictactoe.player.*;

public class TestSpiel {
	public static void main(String[] args) {
//		T3Starter.starte_partie(1000, new CrazySpieler("Crazy") , new ZufallsSpieler("Zufall"));
		T3Starter.starte_partie(1000, new T3DamnAwesomePlayer("MY") , new NichtVerlierer("Nicht Verlierer "));
	}
}
	