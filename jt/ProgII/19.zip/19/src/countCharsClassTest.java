import static org.junit.Assert.*;
import java.util.Map;
import org.junit.Test;

/**
 * Testfaelle, die die Implementierung abpruefen sollen. Vorgabe der Aufgabe
 * 19.1
 * 
 * @author Nane Kratzke
 *
 */
public class countCharsClassTest {

	/**
	 * Pruefe ob countChars bei einem typischen Aufruf funktioniert.
	 */
	@Test
	public void testCaseInsensitive() {
		Map<Character, Integer> m = countCharsClass.countChars(false,
				"sHello Worlds", 's', 'e', 'w');

		// Pruefe die Struktur der Rueckgabe
		assertTrue(m.keySet().size() == 6);
		assertTrue(m.keySet().contains('s'));
		assertTrue(m.keySet().contains('e'));

		// Pruefe Inhalt der Rueckgabe
		assertTrue(m.get('s') == 2);
		assertTrue(m.get('e') == 1);
		System.out.println("test1 " + m);
	}

	/**
	 * Pruefe ob countChars case sensitive korrekt verarbeitet.
	 */
	@Test
	public void testCaseSensitive() {
		Map<Character, Integer> m = countCharsClass.countChars(true,
				"Hello World", 'H' , 'd');

		assertTrue(m.get('H') == 1);
		assertTrue(m.get('d') == 1); //first and last
		
//		assertTrue(m.get('e') == 1);
//		assertTrue(m.get('W') == 1);
//		assertTrue(m.get('!') == 0);

		System.out.println("test2 " + m);
	}

	@Test
	public void testCaseSensitive2() {
		Map<Character, Integer> m = countCharsClass.countChars(true,"");
		assertTrue(m.isEmpty());
		
	}
	
}
