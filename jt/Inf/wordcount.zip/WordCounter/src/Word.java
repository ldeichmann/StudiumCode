public class Word implements Comparable<Word> {
	
	private String content; // das Wort als Zeichenkette
	private int n; // die Anzahl des Auftretens dieses Wortes im Text
	
	public Word(String s) {
		// s als content übernehmen,
		// zähler auf 1 setzen (erstes Auftreten)
		s = content;
		n = 1;
	}
	
	public int count() { 
		return n; 
	}
	
	public String content() {
		return content;
	}
	
	public void inc() { // erhöhe Zähler für dieses Wort um 1 
		n++;
	}
	
	public int compareTo(Word w) {
		
			// Die Methode compareTo liefert
			// einen Wert kleiner 0, wenn das Objekt »kleiner«;
			// größer 0, wenn es »größer«,
			// und gleich 0, wenn es »gleich«
			// dem als Argument übergebenen Objekt w ist.
		return n;
	}
	
	public String toString(){
			// liefert für dieses Wort die Zeichenkette: "Häufigkeit : Wort"
			return content + " : " + n;
	}
}