import java.util.Scanner;

public class Wc {
	public static void main(String[] args) {
		AllWords words = new AllWords(15000);
		Scanner scanner = new Scanner(System.in);
		while (scanner.hasNext()) {
			if(scanner.next().equals("exit")) {break;}
			String t = scanner.next().replaceAll("[^\\p{L}\\p{Nd}]+", "");
			words.add(t);
		}
		scanner.close();
		System.out.println(words.toString()); // gib alle Wörter aus
		System.out.println(words.distinctWords()); // gib Vokabulargröße aus
		System.out.println(words.totalWords()); // gib Textlänge aus
	}
}