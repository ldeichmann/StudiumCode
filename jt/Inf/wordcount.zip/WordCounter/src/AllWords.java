import java.util.Arrays;

public class AllWords {
	private Word words[]; // das Array, in dem alle Wörter erfasst
	private int siz = 0;

	public AllWords(int max) {
		words = new Word[max];
	}

	public void add(String s) {
		// Vergleiche mit allen bereits im Array erfassten Wörtern.
		// Falls s bereits als Wort enthalten ist, erhöhe den Zähler
		// dieses Wortes.
		// Ansonsten erzeuge neues Wort und trage es in das Array ein.
		// Falls kein Platz für neue Wörter mehr ist (bereits
		// max Wörter eingetragen) erzeuge Fehlerausschrift und beende
		// Programm mit System.exit(-1).
		
		boolean found = false;
		Word n = new Word(s);

		if (siz == 0) {
			words[0] = n;
		}

		else {
			for (Word c : words) {
				if (c.content().equals(n.content())) {
					c.inc();
					found = true;
					break;
				}
			}
		}

		if (found == false) {
			if (words.length == siz) {
				System.out.printf("fehler");
				System.exit(-1);

			} else {
				siz++;
				words[siz] = n;
			}
		}
	}

	public int distinctWords() {
		// liefere Anzahl der unterschiedlichen Wörter
		return siz;
	}
	public void sort() {
		
		Word newWords[] = new Word[siz]; // newArray
		
		System.arraycopy( words, 0, newWords, 0, siz );
		
		words = newWords;
		Arrays.sort(words);
		
	}

	public int totalWords() {
		// liefere Gesamtzahl aller Wörter
		int cnt = 0;
		for(int c=0;c < siz; c++) {
			cnt = cnt + words[c].count();
		}
		return cnt;
	}

	public String toString() {
		// liefere Stringrepraesentation aller Wörter
		String Str = "";
		for(int i = 0; i < siz; i++) {
			Str = Str + words[i].toString() + "\n";
		}
		return Str;
	}
}