
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class BinBaum<E> implements Iterable<E> {
	protected Knoten<E> wurzel;

	enum Order {
		PREORDER, POSTORDER, INORDER, LEVELORDER
	}

	protected Order order = Order.PREORDER;

	BinBaum() {

	}

	BinBaum(Knoten<E> w) {
		setWurzel(w);
	}

	public void setOrder(Order ord) {
		order = ord;
	}

	public boolean istLeer() {
		if (getWurzel() == null)
			return true;
		else
			return false;
	}

	public int anzKnoten() {
		return anzKnoten(getWurzel());
	}

	public int anzKnoten(Knoten<E> k) {
		if (k == null)
			return 0;
		if(k.links == null && k.rechts == null)
			return 1;
		return 1 + anzKnoten(k.links) + anzKnoten(k.rechts);
	}

	public int anzBlaetter() {
		return anzBlaetter(getWurzel());
	}
	
	public int anzBlaetter(Knoten<E> knoten) {
		if(knoten == null)
			return 0;
		if(knoten.links == null && knoten.rechts == null)
			return 1;
		
		return anzBlaetter(knoten.links) + anzBlaetter(knoten.rechts);
	}

	public int anzInnereKnoten() {
		return anzInnereKnoten(getWurzel());
	}
	
	public int anzInnereKnoten(Knoten<E> knoten) {
		return anzBlaetter(knoten) + 1;
	}

	int hoehe(Knoten<E> k) {
		if (k == null)
			return -1;
		return 1 + Math.max(hoehe(k.links), hoehe(k.rechts));
	}

	public int hoehe() {
		return hoehe(getWurzel());
	}

	public Iterator<E> iterator() {
		List<E> liste = new ArrayList<E>();
		switch (order) {
		case PREORDER:
			preOrder(getWurzel(), liste);
			break;
		case POSTORDER:
			postOrder(getWurzel(), liste);
			break;
		case INORDER:
			inOrder(getWurzel(), liste);
			break;
		case LEVELORDER:
			levelOrder(liste);
			break;
		}
		return liste.iterator();
	}

	private void inOrder(Knoten<E> k, List<E> liste) {
		if (k != null) {
			inOrder(k.links, liste);
			liste.add(k.inhalt);
			inOrder(k.rechts, liste);
		}
	}

	private void preOrder(Knoten<E> k, List<E> liste) {
		if (k != null) {
			liste.add(k.inhalt);
			preOrder(k.links, liste);
			preOrder(k.rechts, liste);
		}
	}

	private void postOrder(Knoten<E> k, List<E> liste) {
		if (k != null) {
			postOrder(k.links, liste);
			postOrder(k.rechts, liste);
			liste.add(k.inhalt);
		}
	}

	public void levelOrder(List<E> liste) {
		Queue<Knoten<E>> q = new LinkedList<Knoten<E>>();
		q.add(getWurzel());
		while (!q.isEmpty()) {
			Knoten<E> kn = (Knoten<E>) q.remove();
			liste.add(kn.inhalt);
			if (kn.links!=null) q.add(kn.links);
			if (kn.rechts!=null) q.add(kn.rechts);
		}

	}
	
	public int oneChild() {
		return oneChild(getWurzel());
	}
	
	public int oneChild(Knoten<E> k) {
		if(k == null)
			return 0;	
		else if(k.links != null && k.rechts == null)
			return 1 + oneChild(k.links);
		else if(k.links == null && k.rechts != null)
			return 1 + oneChild(k.rechts);
		
		return oneChild(k.links) + oneChild(k.rechts);
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (E e : this)
			sb.append(e + " ");
		return sb.toString();
	}

	public Knoten<E> getWurzel() {
		return wurzel;
	}

	public void setWurzel(Knoten<E> wurzel) {
		this.wurzel = wurzel;
	}

}
