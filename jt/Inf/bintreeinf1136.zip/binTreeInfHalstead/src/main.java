import java.util.Scanner;

import org.antlr.runtime.ANTLRInputStream;
import org.antlr.runtime.CharStream;
import org.antlr.runtime.Token;


public class main {
	public static void main(String[] args) {
	
		
		Scanner s = new Scanner(System.in);
		SuchBaum<String> bn= new SuchBaum<String>();

		while (s.hasNext()) {
			String t  = s.next().replaceAll("[^\\p{L}\\p{Nd}]+", "");
			if(t.equals("exit")) { break; }
			bn.einfuegen(t);
		}
		
		System.out.println(bn.size());
		bn.ausgabeVorw();
	}
	
	public static void main2(String[] args) {
		SuchBaum bn= new SuchBaum<>();
		CharStream input = null;
		Scanner s = new Scanner(System.in);
		input = new ANTLRInputStream(System.in);
		HalsteadLexer lex = new HalsteadLexer(input);
//		System.out.println("worked");
		
		Token t = lex.nextToken();
		while ( t==null || t.getType()!= HalsteadLexer.EOF ) {//Token.EOF works as well
			if(t.equals("next")){System.out.println("breaking");break;}
			System.out.printf("%2d:%2d Typ-Code: %2d Lexem: %s\n",t.getLine(),t.getCharPositionInLine() + 1,t.getType(),t.getText());
			t = lex.nextToken();
			System.out.println(t);
			bn.einfuegen(lex.nextToken());
		}
		
		System.out.println(bn);
	}
}
