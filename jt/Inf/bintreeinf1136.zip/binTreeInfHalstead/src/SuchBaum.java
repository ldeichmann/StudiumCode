import java.util.Collection;
import java.util.Comparator;
import java.util.SortedSet;

import org.antlr.runtime.Token;


public class SuchBaum<E extends Comparable<E>> extends BinBaum<E> implements SortedSet<E> {

	public SuchBaum() {

	}

	public boolean istLeer() {
		return false;
	}

	public void loescheBaum() {

	}

	public boolean einfuegen(Token token) {
		return false;
	}

	public boolean einfuegen(E e) {
		if (wurzel == null) {
			wurzel = new Knoten<E>(e);
			return true;
		} else
			return einfuegen(e, wurzel);
	}

	boolean einfuegen(E e, Knoten<E> k) {
		if (e.compareTo(k.inhalt) == 0)
			return false;
		if (e.compareTo(k.inhalt) < 0)
			if (k.links == null)
				k.links = new Knoten<E>(e);
			else
				einfuegen(e, k.links);
		else if (k.rechts == null)
			k.rechts = new Knoten<E>(e);	
		else
			einfuegen(e, k.rechts);
		return true;
	}

	public E sucheMin() {
		Knoten<E> k = sucheMin(getWurzel());
		return k == null ? null : k.inhalt;
	}

	Knoten<E> sucheMin(Knoten<E> k) {
		if (k == null)
			return k;
		while (k.links != null)
			k = k.links;
		return k;
	}

	public Knoten<E> sucheMax(Knoten<E> k) {
		if (k == null)
			return k;
		while (k.rechts != null)
			k = k.rechts;
		return k;
	}

	public void loesche(Knoten<E> k) {
		if (k == null)
			return;
		if (k.links == null || k.rechts == null)
			loesche01(k);
		else
			loesche2(k);
	}

	void loesche01(Knoten<E> sohn) {
		// Bestimme den Enkel - kann null sein
		Knoten<E> enkel = (sohn.links == null) ? sohn.rechts : sohn.links;
		// sohn hat keinen Vater also soll die Wurzel gelöscht werden
		if (sohn == wurzel) {
			wurzel = enkel;
			if (wurzel != null)
				wurzel.oben = null;
			return;
		}
		// Ab hier ist klar: Vater existiert
		Knoten<E> vater = sohn.oben;
		// Verbinde Vater zum Enkel
		if (vater.links == sohn)
			vater.links = enkel;
		else
			vater.rechts = enkel;
		// Verbinde Enkel zum Vater
		if (enkel != null)
			enkel.oben = vater;
	}

	void loesche2(Knoten<E> k) {
		Knoten<E> min = sucheMin(k.rechts);
		k.inhalt = min.inhalt; // Kopiere Inhalt nach oben
		loesche01(min);
	}

	public Knoten<E> suche(E e, Knoten<E> k) {
		if (k == null)
			return null;
		if (e.compareTo(k.inhalt) == 0)
			return k;
		if (e.compareTo(k.inhalt) < 0)
			return suche(e, k.links);
		else
			return suche(e, k.rechts);
	}

	Knoten<E> nachfolger(Knoten<E> k) {
		if (k == null)
			return k;
		if (k.rechts != null)
			return sucheMin(k.rechts);
		Knoten<E> vater = k.oben;
		while ((vater != null) && (vater.rechts == k)) {
			k = vater;
			vater = k.oben;
		}
		return vater;
	}

	public void ausgabeVorw() {
		Knoten<E> k = sucheMin(getWurzel());
		while (k != null) {
			System.out.print(k);
			k = nachfolger(k);
		}
		System.out.println();
	}

	public void ausgabeRueckw() {

	}

	@Override
	public boolean add(E arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(Collection<? extends E> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean contains(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeAll(Collection<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean retainAll(Collection<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int size() {
		return this.anzBlaetter();
	}

	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T[] toArray(T[] arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Comparator<? super E> comparator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E first() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SortedSet<E> headSet(E arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E last() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SortedSet<E> subSet(E arg0, E arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SortedSet<E> tailSet(E arg0) {
		// TODO Auto-generated method stub
		return null;
	}
}
