
public class Knoten<E> {
	Knoten<E> links, rechts, oben;
	E inhalt;
	public static int anz;
	
	Knoten(E el) {
		inhalt = el;
	}
	
	Knoten(E el, Knoten<E> li, Knoten<E> re) {
		inhalt=el;
		links = li;
		rechts = re;
		anz++;
	}
	
	Knoten(E el, Knoten<E> li, Knoten<E> re, Knoten<E> o) {
		inhalt = el;
		links = li;
		rechts = re;
		oben = o;
		anz++;
	}
	

}
