
public class Heap<E extends Comparable<E>> {
	public Heap(int len) {
		
	}
	
	public Heap(E[] b) {
		
	}
	
	public void insert(E e) {
		
	}
	
	private void upHeap(int i) {
		
	}
	
	public E extractMax() {
		return null;
	}
	
	private void heapify(int i) {
		
	}
	
	private int heapifyLocally(int i) {
		return 0;
	}
}
