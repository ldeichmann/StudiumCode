import java.util.Iterator;
import java.util.Set;

public class TreeMultiSet<E extends Comparable<E>> implements Multiset<E>{
	
	SuchBaum<Entry<E>> s = new SuchBaum<Entry<E>>();

	int cnt = 0;
	
	@Override
	public int size() {
		return s.size();
	}

	@Override
	public boolean isEmpty() {
		return s.size() == 0;
	}

	@Override
	public boolean contains(E e) {
		return s.contains(new EntryImpl<E>(e));
	}

	@Override
	public boolean add(E e) {
		Entry<E> entry = new EntryImpl<E>(e);
		if(s.suche(entry) == null) {
			s.einfuegen(entry);
			return true;
		}
		else {
			s.suche(entry).incCount();
		}
		cnt++;
		return false;
	}

	@Override
	public boolean remove(E e) {
		return s.remove(e);
	}

	@Override
	public void clear() {
	}

	@Override
	public E getMatch(E e) {
		Entry<E> entry = new EntryImpl<E>(e);
		return s.suche(entry).getElement();
	}

	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int count(E element) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int distinct() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();

		for(Entry<E> e: s) {
			sb.append(e.getElement().toString() + " \t " + e.getCount() + '\n');
		}
		return sb.toString();
	}

}
