


public class EntryImpl<E extends Comparable> implements Entry<E> {

	E n;
	int cnt = 1;
	
	EntryImpl(E e) {
		n = e;
	}
	
	@Override
	public int compareTo(Entry<E> arg0) {
		return n.compareTo(arg0.getElement());
	}

	@Override
	public E getElement() {
		return this.n;
	}

	@Override
	public int getCount() {
		return cnt;
	}

	@Override
	public void incCount() {
		cnt++;
	}

	@Override
	public void decCount() {
		cnt--;
	}
	
}
