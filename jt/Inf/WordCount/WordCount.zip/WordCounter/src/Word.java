
public class Word {

}
