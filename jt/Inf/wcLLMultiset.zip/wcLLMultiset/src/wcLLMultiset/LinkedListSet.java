package wcLLMultiset;

import java.util.Iterator;

//import wcLLSet.LinkedList;
//import wcLLSet.Set;

class LinkedListSet<E extends Comparable<E>> implements Set<E> {

	LinkedList<E> ll = new LinkedList<E>();
	
	@Override
	public int size() {
		return ll.size();
	}

	@Override
	public boolean isEmpty() {
		return ll.isEmpty();
	}

	@Override
	public boolean contains(E e) {
		return (ll.contains(e));
	}

	@Override
	public boolean add(E e) {
		return (ll.add(e));
	}

	@Override
	public boolean remove(E e) {
		return (ll.remove(e));
	}

	@Override
	public void clear() {
		ll.clear();
		
	}

	@Override
	public E getMatch(E e) {
		return ll.getMatch(e);
	}

	@Override
	public Iterator<E> iterator() {
		return ll.iterator();
	}

//	@Override
//	public Iterator<E> iterator() {
//		return ll.iterator();
//	}


}
