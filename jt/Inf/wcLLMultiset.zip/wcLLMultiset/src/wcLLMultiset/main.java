package wcLLMultiset;


import java.util.Scanner;

public class main {
	public static void main(String args[]) {
		
		Scanner s = new Scanner(System.in);
		Multiset<String> ms = new LinkedListMultiset<>();
		ms.add("und"); 
		ms.add("und"); 

		ms.add("oder"); 
		ms.add("oder"); 
		ms.add("oder");

		while (s.hasNext()) {
			String t  = s.next().replaceAll("[^\\p{L}\\p{Nd}]+", "");
			if(t.equals("exit")) { break; }
			ms.add(t);
		}

		System.out.println(ms);
		System.out.println(ms.size());
		s.close();
	}
}


