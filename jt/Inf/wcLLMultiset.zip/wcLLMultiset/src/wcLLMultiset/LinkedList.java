package wcLLMultiset;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

class LinkedList<E extends Comparable<E>> implements List<E> {
	private Zelle<E> anker;
	private Cursor<E> cursor;
	

	LinkedList() {
		anker = new Zelle<E>(null, null);
		cursor = new Cursor(anker);
	}

	private class Cursor<E extends Comparable<E>> implements Iterator<E> {
		private Zelle<E> z;

		public Cursor(Zelle<E> z) {
			this.z = z;
		}

		private void goToFirst() {
			z = (Zelle<E>) anker;
		}

		private boolean atEnd() {
			return z.next == null;
		}

		private void goToNext() {
			if (!atEnd())
				z = z.next;
		}

		private void goTo(E e) {
			goToFirst();
			while (!atEnd() && e.compareTo(get()) != 0)
				goToNext();
		}
		
		private void add(E e) {
			z.next = new Zelle<E>(e, z.next);
			goToNext();
		}

		public void remove() {
			if (!atEnd())
				z.next = z.next.next;
		}

		private E get() {
			return z.next.inhalt;
		}

		public boolean hasNext() {
			return !atEnd();
		}

		public E next() {
			E e = get();
			goToNext();
			return e;
		}
	}

	public int size() {
		int cnt = 0;
		goToFirst();
		while(!atEnd()) {
			cnt++;
			goToNext();
		}
		return cnt;
	}

	public boolean isEmpty() {
		return (anker == null);
 	}

	
	public boolean contains(E e) {
		if(this.isEmpty()) return false;
		goToFirst();
		while(!cursor.atEnd()) {
			if(e.compareTo(cursor.get()) == 0 ) { return true; }
			cursor.goToNext();
		}
		return false;
	}


	public void clear() {
		goToFirst();
		while(!cursor.atEnd()) {
			cursor.remove();
		}
	}

	public E getMatch(E e) {
		while(!cursor.atEnd()) {
			if (e.compareTo(cursor.get()) == 0 )  { return cursor.get(); }
			cursor.goToNext();
			if (e == cursor.get() )
				return e;
		}
		return null;
	}

	public void goToFirst() {
		cursor.goToFirst();
	}

	public void goToNext() {
		cursor.goToNext();
	}

	public boolean atEnd() {
		return cursor.atEnd();
	}

	public boolean add(E e) {
		cursor.add(e);
		return true;
	}

	public boolean remove() {
		if (cursor.atEnd())
			return false;
		else {
			cursor.remove();
			return true;
		}
	}

	public void goTo(E e) {
		cursor.goTo(e);
	}

	public E get() {
		if (cursor.atEnd())
			return null;
		else
			return (E) cursor.get();
	}
	
	public Iterator<E> iterator() {
		return new Cursor(anker); 
	}

	///////////////////////////////////////
	@Override
	public void add(int arg0, E arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean addAll(Collection<? extends E> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(int arg0, Collection<? extends E> arg1) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean contains(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public E get(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int indexOf(Object arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int lastIndexOf(Object arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ListIterator<E> listIterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ListIterator<E> listIterator(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean remove(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public E remove(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeAll(Collection<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean retainAll(Collection<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public E set(int arg0, E arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<E> subList(int arg0, int arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T[] toArray(T[] arg0) {
		// TODO Auto-generated method stub
		return null;
	}
}

