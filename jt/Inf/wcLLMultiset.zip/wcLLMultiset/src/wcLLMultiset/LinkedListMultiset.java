package wcLLMultiset;

import java.util.Iterator;


public class LinkedListMultiset<E extends Comparable<E>> implements Multiset<E>{
	
	Set<Entry<E>> s = new LinkedListSet<Entry<E>>();
	
//	LinkedList l = new LinkedListSet();
	
	private int cnt = 0;
	
	// liefert die Häufigkeit des Elementes
	public int count(E element) {
		return s.getMatch(new EntryImpl<E>(element)).getCount();
	} 
	
	// liefert die Anzahl der verschiedenen Elemente
	public int distinct() {
		return s.size();	
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(Entry<E> e: s) {
			sb.append(e.getElement().toString() + " : " + e.getCount() + '\n');
		}
		return sb.toString();
	}
	
	//////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////
	


	public int size() {
		return cnt;
	}


	public boolean isEmpty() {
		return s.isEmpty();
	}


	public boolean add(E e) {
		Entry<E> entry = new EntryImpl<E>(e);
		if(!s.contains(entry)) {
			s.add(entry);
			return true;
		}
		else {
			s.getMatch(entry).incCount();
		}
		cnt++;
		return false;
	}

	public void clear() {
		s.clear();
	}

	public E getMatch(E e) {
		return s.getMatch(new EntryImpl<E>(e)).getElement();
	}

	public boolean contains(E e) {
		return s.contains(new EntryImpl<E>(e));
	}

	public boolean remove(E e) {
		Entry<E> k = new EntryImpl<E>(e);
		if(s.contains(k)) {
			k = s.getMatch(k);
			cnt--;
			k.decCount();
			if(k.getCount() == 0) {
				s.remove(k);
			}
			return true;
		}
		return false;
	}

	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}


}
