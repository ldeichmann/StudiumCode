import jdk.nashorn.internal.parser.Token;


public class Int extends Atomic {

	public Int(Token t) {
		super(t);
		// TODO Auto-generated constructor stub
	}
	
	public double eval() {
		return 0;
	}

}
