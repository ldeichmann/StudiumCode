import jdk.nashorn.internal.parser.Token;


public class Add extends Binary{

	public Add(Expr left, Token t, Expr right) {
		super(left, t, right);
	}
	
	public void printInOrder() {
		getLeft().printInOrder();
		System.out.println("+");
		getRight().printInOrder();
	}
	
	public double eval() {
		return 0;
	}
	
}
