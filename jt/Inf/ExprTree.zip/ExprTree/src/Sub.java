import jdk.nashorn.internal.parser.Token;


public class Sub extends Binary{

	public Sub(Expr left, Token t, Expr right) {
		super(left, t, right);
		// TODO Auto-generated constructor stub
	}
	
	public double eval() {
		return 0;
	}

}
