import jdk.nashorn.internal.parser.Token;


public class Node {	
	protected Token token;
	
	public Node() {
		;
	}
	
	public Node(Token t) {
		this.setToken(t);
	}
	
	public String toString() {
		return getToken().toString();
	}
	
	public Token getToken() {
		return token;
	}
	
	public void setToken(Token t) {
		token = t;
	}
	
	
	
	
	
	
}
