import jdk.nashorn.internal.parser.Token;


public class Atomic extends Expr {

	public Atomic(Token t) {
		super(t);
	}

	public void printInOrder() {
		System.out.println(getToken());
	}
	
	
}
