import jdk.nashorn.internal.parser.Token;


public class Binary extends Expr {

	private Expr left;
	private Expr right;
	
	public Binary(Expr left, Token t, Expr right) {
		super(t);
		this.setLeft(left);
		this.setRight(right);
	}
	public Expr getLeft() {
		return left;
	}
	
	public void setLeft(Expr e) {
		left = e;
	}
	
	public Expr getRight() {
		return right;
	}
	
	public void setRight(Expr e) {
		right = e;
	}
	
	public void printInOrder() {
		getLeft().printInOrder();
		System.out.print(getToken());
		getRight().printInOrder();
	}
	
}
