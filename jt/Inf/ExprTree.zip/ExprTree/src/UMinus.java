import jdk.nashorn.internal.parser.Token;


public class UMinus extends Unary{

	public UMinus(Expr child, Token t) {
		super(child, t);
	}
	
	public void printInOrder() {
		getChild().printInOrder();
		System.out.println("-");
	}
	
	public double eval() {
		return 0;
	}
}
