import jdk.nashorn.internal.parser.Token;

public class main {
	public static void main(String[] args) {


	}
}
