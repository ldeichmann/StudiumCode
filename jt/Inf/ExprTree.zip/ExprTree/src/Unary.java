import jdk.nashorn.internal.parser.Token;


public class Unary extends Expr{

	private Expr child;
	
	public Unary(Expr e, Token t) {
		super(t);
		child = e;
	}
	
	public Expr getChild() {
		return child;
	}
	
	public void setChild(Expr e) {
		child = e;
	}
	
	public void printInOrder() {
		getChild().printInOrder();
		System.out.println(getToken());
	}
}
