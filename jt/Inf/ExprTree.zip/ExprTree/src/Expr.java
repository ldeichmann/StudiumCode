import jdk.nashorn.internal.parser.Token;


public abstract class Expr extends Node{
	public Expr(Token t) {
		super(t);
	}
	
	public abstract void printInOrder();
	
	public double eval() {
		return 0;
	}
}
