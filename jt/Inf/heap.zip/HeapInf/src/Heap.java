
import java.util.ArrayList;

//public class Heap<E extends Comparable<E>> implements PriorityQueue {
	public class Heap<E extends Comparable<E>> {
	
//		E[] heap;
		int[] heap;
//		private int size = 0;
	/**
	 * Erzeugt einen leeren Heap (heapgröße[A] = 0) der
	 * len Elemente speichern kann (länge[A] = len).
	 * @param len
	 */
	public Heap(int len) {
//		heap = (E[]) new Object[len];
		heap = new int[len];
	}
	
	/**
	 * Erzeugt mit Hilfe des BUILDHEAP-Algorithmus einen
	 * vollen Heap der die Elemente aus b enthält
	 * (heapgröße[A] = len, länge[A] = len)
	 * @param b
	 */
	public Heap(int[] b) {
//		heap = (E[]) new Object[b.length];
		heap = new int[b.length];
		for(int i = 0; i <= b.length; i++) {
			heap[i] = b[i];
		}
	}
	
	/**
	 * Fügt das Element e in den Heap ein und stellt die
	 * Heapordnung wieder her.
	 * @param e
	 */
	public void insert(int e) {
		if(e != 0) {
			heap[heap.length - 1] = e;
			upHeap(heap.length-1);
		}
	}
	
	/**
	 * Lässt das Element an der Position i nach oben
	 * wandern, bis die Heapordnung wieder hergestellt ist.
	 * @param i
	 */
	private void upHeap(int i) {
		while(i > 1 && heap[i] > heap[Math.abs(i/2)]) {
			heap[Math.abs(i/2)] = heap[i];
			i = Math.abs(i/2);
		}
	}
	
	/**
	 * Liefert das größte Element zurück und entfernt es aus
	 * dem Heap. Die Heapordnung wird wieder hergestellt.
	 * @return
	 */
//	public E extractMax() {
	public int extractMax() {
		int heapgroesse = heap.length-1;
		int max = heap[1];
		heap[1] = heap[heapgroesse];
		heapgroesse--;
		heapify(1);
		return max;
	}
	
	/**
	 * Stellt die Heapordnung für den Teilbaum her, dessen
	 * Wurzel das Element an der Position i ist.
	 * @param i
	 */
	private void heapify(int i) {
		while( i != -1) {
			i = heapifyLocally(i);
		}
	}
	
	/**
	 * Stellt die Heapordnung für den Knoten an der Position
	 * i her. Rückgabe: neue Position des Elementes oder
	 * ein Wert kleiner 0, wenn nicht bewegt.
	 * @param i
	 * @return
	 */
	private int heapifyLocally(int i) {
		int tmp = extractMax();
		if(heap[tmp] > heap[i]) {
			heap[tmp] = heap[i];
			return tmp;
		}
		else 
			return -1;
	}

	public void insert(Object e) {
		// TODO Auto-generated method stub
	}

}
