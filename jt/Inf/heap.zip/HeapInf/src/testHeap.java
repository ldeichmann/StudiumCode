
public class testHeap {
	public static void main(String[] args) {
		
		Heap<Integer> heap = new Heap<Integer>(20);
		
		for(int i = 1; i < 20 ; i+=2) {
			heap.insert(i);
		}
		
		for(int i = 1; i < 20 ; i++) {
			System.out.println(heap.extractMax());
		}
		
		
		
	}
}
