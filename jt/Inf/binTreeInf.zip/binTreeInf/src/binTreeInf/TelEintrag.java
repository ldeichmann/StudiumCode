package binTreeInf;

public class TelEintrag extends BinBaum {
	String name;
	String nr;

	TelEintrag(String s, String n) {
		name = s;
		nr = n;
	}
	public String toString() {
		return "( " + name + ": " + nr + " )\n";
	}
}
