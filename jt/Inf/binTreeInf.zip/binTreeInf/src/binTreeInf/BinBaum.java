package binTreeInf;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class BinBaum<E> implements Iterable<E> {
	private Knoten<E> wurzel;

	enum Order {
		PREORDER, POSTORDER, INORDER, LEVELORDER
	}

	protected Order order = Order.PREORDER;

	BinBaum() {

	}

	BinBaum(Knoten<E> w) {
		wurzel = w;
	}

	public void setOrder(Order ord) {
		order = ord;
	}

	public boolean istLeer() {
		if (wurzel == null)
			return true;
		else
			return false;
	}

	public int anzKnoten() {
		return anzKnoten(wurzel);
	}

	public int anzKnoten(Knoten<E> k) {
		if (k == null)
			return 0;
		return 1 + anzKnoten(k.links) + anzKnoten(k.rechts);
	}

	public int anzBlaetter() {
		return anzKnoten() - 1;
	}

	public int anzInnereKnoten() {
		return Knoten.anz;
	}

	int hoehe(Knoten<E> k) {
		if (k == null)
			return -1;
		return 1 + Math.max(hoehe(k.links), hoehe(k.rechts));
	}

	public int hoehe() {
		return hoehe(wurzel);
	}

	public Iterator<E> iterator() {
		List<E> liste = new ArrayList<E>();
		switch (order) {
		case PREORDER:
			preOrder(wurzel, liste);
			break;
		case POSTORDER:
			postOrder(wurzel, liste);
			break;
		case INORDER:
			inOrder(wurzel, liste);
			break;
		case LEVELORDER:
			levelOrder(wurzel, liste);
			break;
		}
		return liste.iterator();
	}

	private void inOrder(Knoten<E> k, List<E> liste) {
		if (k != null) {
			inOrder(k.links, liste);
			liste.add(k.inhalt);
			inOrder(k.rechts, liste);
		}
	}

	private void preOrder(Knoten<E> k, List<E> liste) {
		if (k != null) {
			liste.add(k.inhalt);
			preOrder(k.links, liste);
			preOrder(k.rechts, liste);
		}
	}

	private void postOrder(Knoten<E> k, List<E> liste) {
		if (k != null) {
			postOrder(k.links, liste);
			postOrder(k.rechts, liste);
			liste.add(k.inhalt);
		}
	}

	public void levelOrder(Knoten<E> k, List<E> liste) {
		Queue<E> q = new LinkedList<E>();
		q.add(wurzel.inhalt);
		while (k != null) {
			
			if (k.links!=null) q.add(k.links.inhalt);
			if (k.rechts!=null) q.add(k.rechts.inhalt);
			}

	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (E e : this)
			sb.append(e + " ");
		return sb.toString();
	}

}
