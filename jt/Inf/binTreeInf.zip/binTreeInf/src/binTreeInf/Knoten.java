package binTreeInf;

public class Knoten<E> {
	Knoten<E> links, rechts;
	E inhalt;
	public static int anz;
	
	Knoten(E el) {
		inhalt = el;
	}
	
	Knoten(E el, Knoten<E> li, Knoten<E> re) {
		inhalt = el;
		links = li;
		rechts = re;
		anz++;
	}
	

}
